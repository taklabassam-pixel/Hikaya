/// <reference types='vite/client' />
